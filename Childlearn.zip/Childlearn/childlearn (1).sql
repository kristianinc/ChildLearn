-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2022 at 11:39 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `childlearn`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` varchar(20) NOT NULL,
  `admin_pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_pass`) VALUES
('AD001', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `assignmentID` int(20) NOT NULL,
  `characters` text NOT NULL,
  `attempt_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `a_status` varchar(20) NOT NULL DEFAULT 'open'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`assignmentID`, `characters`, `attempt_date`, `start_time`, `end_time`, `a_status`) VALUES
(2, 'WERTYUVC', '2022-02-04', '17:56:00', '19:56:00', 'closed'),
(4, 'ABCFGTLK', '2022-02-14', '19:00:00', '20:01:00', 'open');

-- --------------------------------------------------------

--
-- Table structure for table `pupils`
--

CREATE TABLE `pupils` (
  `usercode` varchar(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `phonecontact` int(20) NOT NULL,
  `_status` text NOT NULL DEFAULT 'Activated',
  `action` varchar(20) NOT NULL,
  `request` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pupils`
--

INSERT INTO `pupils` (`usercode`, `firstname`, `lastname`, `phonecontact`, `_status`, `action`, `request`) VALUES
('P001', 'kiiza', 'christian', 755088321, 'Activated', '', ''),
('P002', 'kanyike', 'muhammed', 786234567, 'Activated', '', ''),
('P003', 'lauryn', 'laeticia', 765453421, 'Activated', '', ''),
('P004', 'abigaba', 'marvin', 2147483647, 'Activated', '', ''),
('P005', 'immaculate', 'merry', 786453423, 'Activated', '', ''),
('P006', 'sidney', 'okuni', 756753462, 'Activated', '', ''),
('P008', 'Raymond', 'Nsubuga', 756456763, 'Activated', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `assignmentID` varchar(20) NOT NULL,
  `characters` text NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `usercode` varchar(20) NOT NULL,
  `mark` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `results`
--

INSERT INTO `results` (`assignmentID`, `characters`, `firstname`, `usercode`, `mark`, `time`, `comment`) VALUES
('2', 'WERTYUVC', 'kiiza', 'P001', 100, 71, 'excellent'),
('2', 'WERTYUVC', 'kanyike', 'P002', 53, 74, 'fair'),
('2', 'WERTYUVC', 'lauryn', 'P003', 85, 60, 'fair'),
('2', 'WERTYUVC', 'sidney', 'P006', 85, 43, ''),
('4', 'ABCFGTLK', 'kanyike', 'P002', 82, 40, 'good boy'),
('4', 'ABCFGTLK', 'lauryn', 'P003', 92, 40, ''),
('4', 'ABCFGTLK', 'abigaba', 'P004', 85, 63, 'pull up');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_id` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `tr_name` varchar(20) NOT NULL,
  `tr_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacher_id`, `email`, `tr_name`, `tr_password`) VALUES
('T001', 'xankiiza@gmail.com', 'kiiza', 'test'),
('T002', 'kainerisa@gmail.com', 'erisa', ''),
('T003', 'money@gmail.com', 'futa', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`assignmentID`);

--
-- Indexes for table `pupils`
--
ALTER TABLE `pupils`
  ADD PRIMARY KEY (`usercode`),
  ADD UNIQUE KEY `phonecontact` (`phonecontact`);

--
-- Indexes for table `results`
--
ALTER TABLE `results`
  ADD PRIMARY KEY (`assignmentID`,`usercode`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `assignmentID` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
