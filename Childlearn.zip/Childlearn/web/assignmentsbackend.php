<?php

session_start(); //starting the session for the logged in user


/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$mysqli = new mysqli("localhost", "root", "", "childlearn");
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
 
$assignment = $mysqli->real_escape_string($_REQUEST['assignmentid']);
$characters = $mysqli->real_escape_string($_REQUEST['characters']);
$date = $mysqli->real_escape_string($_REQUEST['date']);
$start = $mysqli->real_escape_string($_REQUEST['start']);
$endtime = $mysqli->real_escape_string($_REQUEST['finish']);

 

$myquery = "select * from assignments where assignmentID = '$assignment'";
$myresult = mysqli_query($mysqli, $myquery);
$num = mysqli_num_rows($myresult);

if($num>=1){// checking so that we wont have many same usernames in the database.
 echo "this assignment ID belongs to another assignment. Reload this page and use a different assignment ID.";

}

else{
// Attempt insert query execution
$sql = "INSERT INTO assignments (assignmentID, characters, attempt_date, start_time,end_time) VALUES ('$assignment', '$characters', '$date','$start','$endtime')";
if($mysqli->query($sql) === true){
    echo "assignment posted successfully";
    header('location:dashboard.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}

}
 
// Close connection
$mysqli->close();
?>