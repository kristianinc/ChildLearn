<?php

session_start();
if(!isset($_SESSION['teacherid'])){
    header('location:login.php');
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

     <!-- Font Awesome for icons -->
     <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
     <link rel="stylesheet" href="menu.css">
     <link rel="stylesheet" href="css/demo.css" />
     <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,400,500,600" rel="stylesheet" type="text/css">
     <link rel="stylesheet" href="https://cdn.datatables.net/1.11.4/css/dataTables.bootstrap4.min.css">
     <!-- <link rel="stylesheet" href="https://cdn.datatables.net/1.11.4/css/jquery.dataTables.min.css"> -->
    <title>Dashboard</title>
    
</head>
<body>

    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CHILDLEARN</label>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="pupilform.php">Register Pupils</a></li>
            <li><a href="assignments.php">Assignments</a></li>
            <li><a href="results.php">Results</a></li>
            <li><a href="logout.php">logout</a></li>
        </ul>
    </nav><br>
    <h2 style="margin-left:40%;">Registered pupils</h2><br>
    
  <!-- <center><form method="post" action="">
      <input type="text" name="search"placeholder="search pupil's name">
      <button>search</button>
  </form></center> -->


    <?php
$conn= mysqli_connect("localhost", "root", "", "childlearn");
if($conn-> connect_error){
    die("connection faied:".$conn-> connect_error);
}

$sql = "select usercode,firstname,lastname,phonecontact,_status,request from pupils";

$result = $conn->query($sql);

if($result->num_rows > 0){

    // while loop to fetch contents of the database
     echo'<div class ="container">';
     echo'<table id="pupils" class="table table-striped">';

     echo'<tr><th>usercode</th><th>firstname</th><th>lastname</th><th>telephone</th><th>status</th><th>action</th><th>requests</th></tr>';

while($row = $result->fetch_assoc()){

    
  $usercode = $row['usercode'];
  $firstname = $row['firstname'];
  $lastname = $row['lastname'];
  $contact   = $row['phonecontact'];
  $status    = $row['_status'];
  $request = $row['request'];

  echo'<form method="post" action="changestatus.php">';
         echo"<tr>";
 echo '<input type="hidden"name="usercode"value="'.$row['usercode'].'">';
 echo '<input type="hidden"name="pupilstatus"value="'.$row['_status'].'">';
  echo '<td> '.$usercode.' </td>';
  echo '<td> '.$firstname.' </td>';
  echo '<td> '.$lastname.' </td>';
  echo '<td> '.$contact.' </td>';
  echo '<td> '.$status.' </td>';

  if($status=="Activated"){
      echo'<td><button class="btn-danger" style="width:60%;border-radius:7px;" name="changestatus">Deactivate</button></td>';
  }  else if($status=="Deactivated") {
    echo'<td><button class="btn-success" style="width:60%;border-radius:7px;" name="changestatus">activate</button></td>';
  } else{echo'<td> </td>';}
    echo '<td>'.$request.'</td>';
  
         echo"</tr></form>";
         echo'</div>';
     } 
     echo"</table";
     echo'</div>';
  } else{ } 

?>

<script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script>
<!-- <script src="https://cdn.datatables.net/1.11.4/js/dataTables.bootstrap4.min.js"></script> 
<script src="https://cdn.datatables.net/1.11.4/js/jquery.dataTables.min.js"></script> -->
<script>
    $(document).ready(function() {
    $('#pupils').DataTable();
} );
</script>


</body>
</html>