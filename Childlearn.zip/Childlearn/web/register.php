<?php
session_start();
//if(isset([$_SESSION])==null){
   // header("location:admin.php");
//}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>register</title>
   
    
    <!-- Font Awesome -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    
    <!-- Stylish Login Page CSS -->
    <link rel="stylesheet" href="css/login-page.css">
    
    <!--Only for demo purpose - no need to add.-->
    <link rel="stylesheet" href="css/demo.css" />
	
</head>
<body>
		
    <div class="rt-container">
        <div class="col-rt-4" id="float-right">
            
        </div>
    </div>
</div>

<header class="ScriptHeader">
    <div class="rt-container">
    	<div class="col-rt-12">
        	<div class="rt-heading">
            	<h1>CHILDLEARN</h1>
                <p>welcome admin</p>
            </div>
        </div>
    </div>
</header>

<section>
    <div class="rt-container">
    <a href="adminlogout.php"><b>LOGOUT</b></a>
          <div class="col-rt-12">
              <div class="Scriptcontent">
              
              <!-- Stylish Login Page Start -->
                <form class="codehim-form"method="post"action="teacherformbackend.php">
        <div class="form-title">
            <div class="user-icon gr-bg">
            <i class="fa fa-user"></i>
            </div>
     <h2> Register a teacher</h2>
            </div>
    <label for="ID"><i class="fa fa-user"></i>Teacher ID:</label>
    <input type="text" id="trid" class="cm-input" placeholder="Enter your teacher ID"name="teacherid">

    <label for="email"><i class="fa fa-envelope"></i>Email:</label>
    <input type="email" id="trid" class="cm-input" placeholder="Enter your email"name="mail">

    <label for="name"><i class="fa fa-user"></i>Name:</label>
    <input type="text" id="trid" class="cm-input" placeholder="Enter your name"name="name">
        
        <label for="pass"><i class="fa fa-lock"></i> Password:</label>
        <input id="password" type="password" class="cm-input" placeholder="Enter your password"name="password">

        <button type="submit" class="btn-login  gr-bg">Register</button>

    </form>
              <!-- Stylish Login Page End -->
    		
    		</div>
		</div>

    <!-- Analytics -->

	</body>
</html>