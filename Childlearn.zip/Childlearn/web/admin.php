<?php


session_start();

	if(isset($_POST['submit'])){

		$adminid = $_POST['adminid'];
		$password = $_POST['password'];

		$conn = new mysqli("localhost", "root", "", "childlearn");

		if($conn->connect_error){
			die("Failed to login".$conn->connect_error);
		}else{
			$stmt = $conn->prepare("SELECT * FROM admin WHERE admin_id = ? AND admin_pass =?");
			$stmt->bind_param("ss",$adminid,$password);
			$stmt->execute();
			$stmt_result = $stmt->get_result();

			 	if($stmt_result->num_rows > 0){
					 $_SESSION['adminid']=$adminid;

					header('Location: register.php');
					exit();
				 }
				 else{
					header('Location: admin.php');
                    echo("wrong adminID or password");
					exit();
				 }
		}
	}
 ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>LOGIN</title>
   
    
    <!-- Font Awesome -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    
    <!-- Stylish Login Page CSS -->
    <link rel="stylesheet" href="css/login-page.css">
    
    <!--Only for demo purpose - no need to add.-->
    <link rel="stylesheet" href="css/demo.css" />
	
</head>
<body>

    <div class="rt-container">
        <div class="col-rt-4" id="float-right">
            
        </div>
    </div>
</div>

<header class="ScriptHeader">
    <div class="rt-container">
    	<div class="col-rt-12">
        	<div class="rt-heading">
            	<h1>CHILDLEARN</h1>
                <p>Admin</p>
            </div>
        </div>
    </div>
</header>

<section>
    <div class="rt-container">
          <div class="col-rt-12">
              <div class="Scriptcontent">
              
                <form class="codehim-form"method="post"action="admin.php">
        <div class="form-title">
            <div class="user-icon gr-bg">
            <i class="fa fa-user"></i>
            </div>
     <h2> login </h2>
            </div>
    <label for="admin"><i class="fa fa-user"></i>Admin ID:</label>
    <input type="text" id="trid" class="cm-input" placeholder="Admin ID"name="adminid">
        
        <label for="pass"><i class="fa fa-lock"></i> Password:</label>
        <input id="password" type="password" class="cm-input" placeholder="Enter your password"name="password">
        <button type="submit" class="btn-login  gr-bg"name="submit">Login</button>
        are you a teacher? <a href="login.php">login here</a>

              </form>   
    		</div>
		</div>
	</body>
</html>