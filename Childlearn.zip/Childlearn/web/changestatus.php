 <?php
    $mysqli = new mysqli("localhost", "root", "", "childlearn");
 
    // Check connection
    if($mysqli === false){
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    }
    

if(isset($_POST['changestatus'])){
    $pupilstatus =$_POST['pupilstatus'];
    $usercode =$_POST['usercode'];

    if($pupilstatus == "Activated"){
        $change= "Deactivated";
    }
    else{
        $change= "Activated";
    }
    
    $space ="";
    $sql ="UPDATE pupils SET _status=?,request=? WHERE usercode like ?;";
    //creating a prepared statement

    $stmt1 =mysqli_stmt_init($mysqli);

    //if it fails to execute
    if(!mysqli_stmt_prepare($stmt1,$sql)){


        header("location:pupillist.php");
        exit();
    }

    mysqli_stmt_bind_param($stmt1,"sss",$change,$space,$usercode);
    //we execute the prepared statement
    mysqli_stmt_execute($stmt1);

    header("location:pupillist.php");
    exit();
}
else{
      header("location:pupillist.php");
      exit();
}
