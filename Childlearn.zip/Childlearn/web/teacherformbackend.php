<?php

session_start(); //starting the session for the logged in user


/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$mysqli = new mysqli("localhost", "root", "", "childlearn");
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
 
$id = $mysqli->real_escape_string($_REQUEST['teacherid']);
$email = $mysqli->real_escape_string($_REQUEST['mail']);
$name = $mysqli->real_escape_string($_REQUEST['name']);
$pass = $mysqli->real_escape_string($_REQUEST['password']);

 

$insertion = "select * from teacher where teacher_id = '$id'";
$myresult = mysqli_query($mysqli, $insertion);
$num = mysqli_num_rows($myresult);

if($num>=1){// checking so that we wont have many same usernames in the database.
 echo "teacher ID belongs to another teacher";

}

else{
// Attempt insert query execution
$sql = "INSERT INTO teacher (teacher_id, email, tr_name,tr_password) VALUES ('$id', '$email', '$name','$pass')";
if($mysqli->query($sql) === true){

    echo "teacher registered successfully";
    header('location:register.php');
   
} else{
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}

}
 
// Close connection
$mysqli->close();
?>