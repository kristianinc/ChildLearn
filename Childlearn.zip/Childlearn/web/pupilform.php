<?php

session_start();
if(!isset($_SESSION['teacherid'])){
    header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>pupil forms</title>
   
    
    <!-- Font Awesome -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    
    <link rel="stylesheet" href="css/login-page.css">
    <link rel="stylesheet" href="css/demo.css" />

    <link rel="stylesheet" href="menu.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Raleway:100,200,400,500,600" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="cards.css">
	
</head>
<body>
    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CHILDLEARN</label>
        <ul>
           <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="pupilform.php">Register Pupils</a></li>
            <li><a href="assignments.php">Assignments</a></li>
            <li><a href="results.php">Results</a></li>
            <li><a href="logout.php">logout</a></li>
        </ul>
    </nav>


<header class="ScriptHeader">
    <div class="rt-container">
    	<div class="col-rt-12">
        </div>
    </div>
</header>

<section>
    <div class="rt-container">
          <div class="col-rt-12">
              <div class="Scriptcontent">
              
              <!-- Stylish Login Page Start -->
                <form class="codehim-form" method="post" action="pupilformbackend.php">
        <div class="form-title">
            <!-- <div class="user-icon gr-bg">
            <i class="fa fa-user"></i>
            </div> -->
     <h2> register a new pupil</h2>
            </div>
    <label for="usercode"><i class="fa fa-user"></i>usercode:</label>
    <input type="text" id="trid" class="cm-input" placeholder="Enter the pupils usercode"name="usercode">

    <label for="fisrtname"><i class="fa fa-user"></i>firstame:</label>
    <input type="text" id="trid" class="cm-input" placeholder="firstname"name="firstname">

    <label for="lastname"><i class="fa fa-user"></i>lastname:</label>
    <input type="text" id="trid" class="cm-input" placeholder="lastname"name="lastname">

    <label for="phone"><i class="fa fa-phone"></i>telephone:</label>
    <input type="text" id="trid" class="cm-input" placeholder="telephone"name="phone">

        <button type="submit" class="btn-login  gr-bg">Register</button>

        wish to deactivate any pupil?, view the pupils <a href="pupillist.php">here</a>.
    </form>
              <!-- Stylish Login Page End -->
    		
    		</div>
		</div>
</div></section>
    <!-- Analytics -->

	</body>
</html>