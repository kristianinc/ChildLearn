<?php

session_start();
if(!isset($_SESSION['teacherid'])){
    header('location:login.php');
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>assignments</title>
   
    <!-- Font Awesome -->
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    
    <!-- Stylish Login Page CSS -->
    <link rel="stylesheet" href="css/login-page.css">
    
    <!--Only for demo purpose - no need to add.-->
    <link rel="stylesheet" href="css/demo.css" />
    <link rel="stylesheet" href="menu.css">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="https://fonts.googleapis.com/css?family=Raleway:100,200,400,500,600" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="cards.css">

<style>
   body{
       /* background-image:url("alphabet.jpg"); */
   }
     </style>
	
</head>
<body>

    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CHILDLEARN</label>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="pupilform.php">Register Pupils</a></li>
            <li><a href="assignments.php">Assignments</a></li>
            <li><a href="results.php">Results</a></li>
            <li><a href="logout.php">logout</a></li>
        </ul>
    </nav>
   
		
    <div class="rt-container">
        <div class="col-rt-4" id="float-right">
            
        </div>
    </div>
</div>

<header class="ScriptHeader">
    <div class="rt-container">
    	<div class="col-rt-12">
        </div>
    </div>
</header>

<section>
    <div class="rt-container">
          <div class="col-rt-12">
              <div class="Scriptcontent">
              
            
                <form class="codehim-form"method="post"action="assignmentsbackend.php">

        <div class="form-title">
           
     <h2> enter characters for attempt</h2>
            </div>
   
    <label for="character"><i class="fa fa-sort-alpha-asc" aria-hidden="true"></i> characters:</label>
    <input type="text" id="trid" class="cm-input" placeholder="Enter characters e.g ABGR.... without space or commas"maxlength="8"name="characters"required>

    <label for="date"><i class="fa fa-calender"></i>date:</label>
    <input type="date" id="date" class="cm-input" placeholder="date"name="date"required>

    <label for="start"><i class="fa fa-clock"></i>start time:</label>
    <input type="time" id="starttime" class="cm-input" placeholder="start time"name="start"required>
        
    <label for="finish"><i class="fa fa-clock"></i> end time:</label>
    <input id="endtime" type="time" class="cm-input" placeholder="End time"name="finish"required>

        <button type="submit" class="btn-login  gr-bg">post assignment</button>

        <a href="results.php">click here</a>. to view recent assignments and results
    </form>
              <!-- Stylish Login Page End -->
    		
    		</div>
		</div>
        
    <!-- Analytics -->

	</body>
</html>