<?php
    $mysqli = new mysqli("localhost", "root", "", "childlearn");
 
    // Check connection
    if($mysqli === false){
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    }
    

if(isset($_POST['openbtn'])){
    $status =$_POST['ass_status'];
    $assid =$_POST['ass_id'];

    if($status == "open"){
        $change= "closed";
    }
    else{
        $change= "open";
    }
    
    $space ="";
    $sql ="UPDATE assignments SET a_status=? WHERE assignmentID like ?;";
    //creating a prepared statement

    $stmt1 =mysqli_stmt_init($mysqli);

    //if it fails to execute
    if(!mysqli_stmt_prepare($stmt1,$sql)){


        header("location:open.php");
        exit();
    }

    mysqli_stmt_bind_param($stmt1,"ss",$change,$assid);
    //we execute the prepared statement
    mysqli_stmt_execute($stmt1);

    header("location:open.php");
    exit();
}
else{
      header("location:pupillist.php");
      exit();
}
