<?php

session_start(); //starting the session for the logged in user


/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$mysqli = new mysqli("localhost", "root", "", "childlearn");
 
// Check connection
if($mysqli === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}
 
$usercode = $mysqli->real_escape_string($_REQUEST['usercode']);
$firstname = $mysqli->real_escape_string($_REQUEST['firstname']);
$lastname = $mysqli->real_escape_string($_REQUEST['lastname']);
$contact = $mysqli->real_escape_string($_REQUEST['phone']);

 

$insertion = "select * from pupils where usercode = '$usercode'";
$myresult = mysqli_query($mysqli, $insertion);
$num = mysqli_num_rows($myresult);

if($num>=1){// checking so that we wont have many same usernames in the database.
 echo "usercode belongs to another pupil";

}

else{
// Attempt insert query execution
$sql = "INSERT INTO pupils (usercode, firstname, lastname,phonecontact) VALUES ('$usercode', '$firstname', '$lastname','$contact')";
if($mysqli->query($sql) === true){
    echo "pupil registered successfully";
    header('location:dashboard.php');
} else{
    echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
}

}
 
// Close connection
$mysqli->close();
?>