<?php
    $myquery = new mysqli("localhost", "root", "", "childlearn");
 
    // Check connection
    if($myquery === false){
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    }
    

if(isset($_POST['commentbtn'])){

    $comment =$_POST['comment'];
    $code = $_POST['usercode'];
    $ass_id = $_POST['ass_id'];

    $sql ="UPDATE results SET comment=? WHERE usercode like ? AND assignmentID like?;";
    //creating a prepared statement

    $stmt1 =mysqli_stmt_init($myquery);

    //if it fails to execute
    if(!mysqli_stmt_prepare($stmt1,$sql)){


        header("location:results.php");
        exit();
    }

    mysqli_stmt_bind_param($stmt1,"sss",$comment,$code,$ass_id);
    //we execute the prepared statement
    mysqli_stmt_execute($stmt1);

    header("location:results.php");
    exit();
}

?>