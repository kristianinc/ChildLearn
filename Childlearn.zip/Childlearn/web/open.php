<?php

session_start();
if(!isset($_SESSION['teacherid'])){
    header('location:login.php');
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>open</title>
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
     <link rel="stylesheet" href="menu.css">
     <link rel="stylesheet" href="css/demo.css" />
     <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
     <link href="https://fonts.googleapis.com/css?family=Raleway:100,200,400,500,600" rel="stylesheet" type="text/css">
</head>
<body>
    <!-- <h1>this page will contain reports and student results</h1> -->

    <nav>
        <input type="checkbox" id="check">
        <label for="check" class="checkbtn">
            <i class="fas fa-bars"></i>
        </label>
        <label class="logo">CHILDLEARN</label>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="pupilform.php">Register Pupils</a></li>
            <li><a href="assignments.php">Assignments</a></li>
            <li><a href="results.php">Results</a></li>
            <li><a href="logout.php">logout</a></li>
        </ul>
    </nav>
<p style="margin-left:5%;"><center><h3>ASSIGNMENTS</h3></center></p><br>

<?php
$conn= mysqli_connect("localhost", "root", "", "childlearn");
if($conn-> connect_error){
    die("connection faied:".$conn-> connect_error);
}

$sql = "select assignmentID,characters,attempt_date,start_time,end_time,a_status from assignments";

$result = $conn-> query($sql);

if($result->num_rows > 0){

    // while loop to fetch contents of the database
     echo'<div class ="container">';
     echo'<table class="table table-striped" style="border-radius:10px;">';

     echo'<tr><th>assignmentID</th>
              <th>characters</th>
              <th>open date</th>
              <th>start time</th>
              <th>end time</th>
              <th>status</th>
              <th>action</th></tr>';

while($row = $result->fetch_assoc()){

    
  $id = $row['assignmentID'];
  $characters = $row['characters'];
  $date = $row['attempt_date'];
  $start   = $row['start_time'];
  $end    = $row['end_time'];
  $status    = $row['a_status'];
  //$request = $row['request'];

         echo"<tr>";
  echo '<td> '.$id.' </td>  ';
  echo '<td> '.$characters.' </td>  ';
  echo '<td> '.$date.' </td>  ';
  echo '<td> '.$start.' </td>  ';
  echo '<td> '.$end.' </td>  ';
  echo '<td> '.$status.' </td>  ';
  echo'<form method="post" action="openstatus.php">';
  echo'<input type="hidden"name="ass_id" value="'.$id.'">';
  echo'<input type="hidden"name="ass_status" value="'.$status.'">';
  if($status=="open"){
  echo'<td><button name="openbtn"class="btn-danger">close</button></td>';
  }
  else{
    echo'<td><button name="openbtn"class="btn-success">open</button></td>';

  }

  echo'</form>';
  //echo '<td><button id="activate">deactivate</button></td>';
  //echo '<td> '.$request.' </td>  ';
  
         echo"</tr>";
     } 
     echo"</table";
     echo'</div>';
  } else{}

?> 
    
</body>
</html>